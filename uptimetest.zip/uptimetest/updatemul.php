<link href="css/style.css" rel="stylesheet" type="text/css">
<?php include("layout/header.html") ?>
<?php
session_start();
require("db.php");

#Function Definations
function sql_error()
{
	$error_msg = "DB Connectivity lost/Could not perform this activity now! Try again.";
	echo "<script type='text/javascript'>alert('$error_msg');</script>";
	
}

function null_selected()
{
	$error_null_msg = "This activity cannot be performed without selecting a row,kindly select one row";
	echo "<script type='text/javascript'>alert('$error_null_msg');window.location.replace(\"index.php\");</script>";
	#sleep(5);
}

if(isset($_POST['updatemul']))

{
	
	
	$select_id = implode(", ", $_POST['check']);
	if($select_id==null)
	{
		null_selected();
	}
	elseif ($select_id==!null){
	include ('main.php');
	$_SESSION['id']=$select_id;
	}
}


if (isset($_POST['updatemult'])) 
	{
		
		$team_mul=$_POST['TEAM_MUL'];
		$reason_mul=$_POST["REASON_MUL"];
		$remarks_mul=$_POST["REMARKS_MUL"];
		/*$username_mul=$_POST["USERNAME_MUL"];*/
		$username_mul=$_SESSION['login_user'];
		
		mysql_query("UPDATE test SET TEAM ='$team_mul', REASON ='$reason_mul',
				REMARKS ='$remarks_mul', USERNAME ='$username_mul'  WHERE SR_NO IN (" . $_SESSION['id'] . ")")
				or die(sql_error());
				
		unset($_SESSION['id']);
		header("Location: index.php");
}

?>
<!DOCTYPE html>
<html>
<body><center>
<div class="footer">
<form method="post">
<table>
<tr>			
				<td>SR_NO</td>
				<td>URL</td>
				<td>START_TIME</td>
				<td>END_TIME</td>
				<td>DURATION</td>
				<td>NUM_CHECKS</td>
				
				<td>
				<select name="TEAM_MUL">
    <option value="GD-RM">GD-RM</option>
    <option value="PDT">PDT</option>
    <option value="GD-IT">GD-IT</option>
    <option value="GD-DB">GD-DB</option>
	<option value="Monitoring">Monitoring</option>
	<option value="False_Alert">False_Alert</option>
	<option value="l2-analytics">l2-analytics</option>
	<option value="Not_UD">Not_UD</option>
	<option value="Doubt">Doubt</option></select></td>
				
				<td><input type="text" name="REASON_MUL" autocomplete="off" required/></td>
				
				<td><select name="REMARKS_MUL">
    <option value="Not Unscheduled Downtime">Not Unscheduled Downtime</option>
    <option value="">Blank</option>
 </select></td>
				<td>USERNAME</td>
				<!---<td><select name="USERNAME_MUL">
    <option value="Mayank">Mayank</option>
    <option value="Mohit">Mohit</option>
    <option value="Rehan">Rehan</option>
    <option value="Anil">Anil</option>
	<option value="Siddhi">Siddhi</option>
	<option value="Dharm">Dharm</option>
	<option value="Amogh">Amogh</option>
	<option value="Kartiki">Kartiki</option></select></td>-->
					<td>SETUP</td>
				<td><input type="submit" name="updatemult" value="Update" class="button button5"/></td></tr>
</table>
</form>
</div>
</center>
</body>
</html>

<?php


?>
