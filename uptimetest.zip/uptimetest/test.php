<?php 
if(isset($_POST['updatemul'])) {

if(isset($_POST['check'])) {

$favLanguages = implode(", ", $_POST['check']); 
//comma is the glue string between each element

echo $favLanguages;

}

}
?>