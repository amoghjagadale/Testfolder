<?php  
	$conn = mysql_connect('localhost', 'root', '');
	 if (!$conn)
    {
	 die('Database connection error ' . mysql_error());
	}
	mysql_select_db("db", $conn);
		
?>

 