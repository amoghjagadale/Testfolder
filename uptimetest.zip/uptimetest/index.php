<link href="css/style.css" rel="stylesheet" type="text/css">
<?php session_start(); ?>
<?php include("layout/header.html") ?>
<!DOCTYPE html>
<html>
<body>
<?php
echo "Hi,",$_SESSION['login_user'];
if(!isset($_SESSION['login_user'])){ 
    header("Location: login.php");
}
?>
<a href = "logout.php">logout</a>	
<form action="updatemul.php" method="post" action ="">
<?php include ('main.php');?>
<div class="footer"><input type="submit" name="updatemul" value="Update Selected"/></div></form>

</body>
</html>
