<link href="css/style.css" rel="stylesheet" type="text/css">
<?php include("layout/header.html") ?>
<?php session_start(); ?>
<?php
require("db.php");
$sr_no =$_REQUEST['sr_no'];

$result = mysql_query("SELECT * FROM test WHERE sr_no  = '$sr_no'");
$test = mysql_fetch_array($result);
if (!$result) 
		{
		die("Database Data Not Found");
		}
		
		$sr_no=$test["SR_NO"];
		$url=$test["URL"];
		$start_time=$test["START_TIME"];
		$end_time=$test["END_TIME"];
		$duration=$test["DURATION"];
		$num_chekcs=$test["NUM_CHECKS"];
		$team=$test["TEAM"];
		$reason=$test["REASON"];
		$remarks=$test["REMARKS"];
		$username=$test["USERNAME"];
							
if(isset($_POST['update']))
{		$team_save=$_POST["TEAM"];
		$reason_save=$_POST["REASON"];
		$remarks_save=$_POST["REMARKS"];
		/*$username_save=$_POST["USERNAME"];*/
		$username_save=$_SESSION['login_user'];	

	mysql_query("UPDATE test SET TEAM ='$team_save', REASON ='$reason_save',
		 REMARKS ='$remarks_save', USERNAME ='$username_save'  WHERE SR_NO = '$sr_no'")
				or die(mysql_error()); 
		header("Location: index.php");			
}
mysql_close($conn);
?>

<!DOCTYPE html>
<html>
<body><center>
<?php
include("index.php")
?>
<div class="footer">
<form method="post">
<table>
<tr>			
				<td><?php echo $sr_no ?></td>
				<td><?php echo $url ?></td>
				<td><?php echo $start_time ?></td>
				<td><?php echo $end_time ?></td>
				<td><?php echo $duration ?></td>
				<td><?php echo $num_chekcs ?></td>
				
				<td>
				<select name="TEAM">
    <option value="GD-RM">GD-RM</option>
    <option value="PDT">PDT</option>
    <option value="GD-IT">GD-IT</option>
    <option value="GD-DB">GD-DB</option>
	<option value="Monitoring">Monitoring</option>
	<option value="False_Alert">False_Alert</option>
	<option value="l2-analytics">l2-analytics</option>
	<option value="Not_UD">Not_UD</option>
	<option value="Doubt">Doubt</option></select></td>
				
				<td><input type="text" name="REASON" value="<?php echo $reason ?>"/></td>
				
				<td><select name="REMARKS">
    <option value="Not Unscheduled Downtime">Not Unscheduled Downtime</option>
    <option value="">Blank</option>
 </select></td>
			<td><?php echo $username?></td>	
				<!---<td><select name="USERNAME">
    <option value="Mayank">Mayank</option>
    <option value="Mohit">Mohit</option>
    <option value="Rehan">Rehan</option>
    <option value="Anil">Anil</option>
	<option value="Siddhi">Siddhi</option>
	<option value="Dharm">Dharm</option>
	<option value="Amogh">Amogh</option>
	<option value="Kartiki">Kartiki</option></select></td>-->
					<td>SETUP</td>
				<td><input type="submit" name="update" value="Update" /></td></tr>
</table>
</form>
</div>
</center>
</body>
</html>
 