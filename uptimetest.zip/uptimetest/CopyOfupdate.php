<?php 
if(isset($_POST['updatemul']))
{
	echo $sr_no;
}
?>