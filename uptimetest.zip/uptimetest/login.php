<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<link href="css/style.css" rel="stylesheet" type="text/css">
<body>
<div class = "login-pane">
<form name="form" action="" method="post">
<table>
<tr>
<td>Username</td>
<td><input type="text" name="username" style="padding:0"></td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" name="password" ></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="submiusername" value="login"></td>
</tr>
</table>
</form>
</div>
<?php
session_start();
if(isset($_POST["submiusername"]))
{
$pwd=($_POST["password"]);
	$link=mysqli_connect("localhost","root","");
	mysqli_select_db($link,"db");
	$count=0;
	$res=mysqli_query($link,"select * from users where USERNAME='$_POST[username]' && PASSWORD='$pwd'");
	$count=mysqli_num_rows($res);
    if($count>0)
	{
	$_SESSION['login_user']= $_POST['username']; 
	?>
	<script type="text/javascript">
	window.location="index.php";
	</script>
	<?php
	
	
	}
	else
	{
	?>
	<script type="text/javascript">
	alert("incorrect username or password");
	</script>
	<?php
	
	}

}

?>


</body>
</html>