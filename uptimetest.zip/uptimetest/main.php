<link href="css/style.css" rel="stylesheet" type="text/css">

<div class="input-append date" id="datepicker" data-date="02-2012" 
         data-date-format="mm-yyyy">
	<input  type="text" readonly="readonly" name="date" >	  
	<span class="add-on"><i class="icon-th"></i></span>	  
</div>

<script type="text/javascript">
	$("#datepicker").datepicker( {
    format: "mm-yyyy",
    viewMode: "months", 
    minViewMode: "months"
});
</script>

<table class="hovertable" style="margin-bottom: 80px">
<?php
include("db.php");
echo"<tr>
				<th>&nbsp;</th>
				<th>SR_NO</th>
				<th>URL</th>
				<th>START_TIME</th>
				<th>END_TIME</th>
				<th>DURATION</th>
				<th>NUM_CHECKS</th>
				<th>TEAM</th>
				<th>REASON</th>
				<th>REMARKS</th>
				<th>USERNAME</th>
				<th>SETUP</th>
				<th>&nbsp;</th></tr>";

#Any changes in the query is made here only(Select table)
$result=mysql_query("SELECT * FROM test");

while($test = mysql_fetch_array($result))
{
	$sr_no = $test['SR_NO'];
	echo '<tr align="center" onmouseover=this.style.backgroundColor="#ececec"; onmouseout=this.style.backgroundColor="#fcfcfc"; onClick=this.style.background="#">';
	echo"<td><input type='checkbox' name='check[]' value='".$test['SR_NO']."'></td>";
	echo"<td>" .$test['SR_NO']."</td>";
	echo"<td>" .$test['URL']."</td>";
	echo"<td>". $test['START_TIME']. "</td>";
	echo"<td>". $test['END_TIME']. "</td>";
	echo"<td>" .$test['DURATION']."</td>";
	echo"<td>" .$test['NUM_CHECKS']."</td>";
	echo"<td>". $test['TEAM']. "</td>";
	echo"<td>". $test['REASON']. "</td>";
	echo"<td>" .$test['REMARKS']."</td>";
	echo"<td>" .$test['USERNAME']."</td>";
	echo"<td>". $test['SETUP']. "</td>";


	echo"<td> <a href ='update.php?sr_no=$sr_no'>Update</a>";
		
	echo "</tr>";
}
mysql_close($conn);
?>
</table>

